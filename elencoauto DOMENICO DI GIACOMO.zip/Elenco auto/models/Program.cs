
//Connessione al DB Mongo 
using auto;
using MongoDB.Driver;

try
{
    var client = new MongoClient ("mongodb://localhost:27017");
    //FASE 2: SELEZIONE Database 
    var database = client.GetDatabase("auto");
    //FASE 3: SELEZIONE Collection
    var collFilm = database.GetCollection<Elenco_auto>("auto");

}
catch
{
    Console.WriteLine("errore");
}