﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Net.NetworkInformation;

namespace auto
{
    internal class auto
        

    {
            [BsonId]
            [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
            public string? Id { get; set; }
        [BsonElement("telaio")]
        public string? telaio { get; set; }
        [BsonElement("marca_auto")]
        public string? marca { get; set; }
        [BsonElement("modello")]
        public string? modello { get; set; }
        [BsonElement("colore")]
        public string? colore { get; set; }

        [BsonElement("Nome e cognome")]
        public string? Nominativo { get;set; }
        [BsonElement("Tipo di documento")]
        public string? documento { get; set; }



           
    }
    }
    


